package dataaccesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database connection
 *
 * References: Ram N. (2013). Data Access Object Design Pattern or DAO Pattern
 * [blog] Retrieved from
 * http://ramj2ee.blogspot.in/2013/08/data-access-object-design-pattern-or.html
 *
 * @author Stanley Pieda
 */
public class DataSource {

    static {
        try {
            // Explicitly register the driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver Registered Successfully");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Failed to load MySQL JDBC driver", e);
        }
    }

    private Connection connection = null;
    private String url = "jdbc:mysql://localhost:3306/books";
    private String username = "cst8288";
    private String password = "CST8288";

    public DataSource() {
    }

    /**
     * Create a connection
     *
     * @return connection
     * @throws SQLException
     */
    public Connection createConnection() throws SQLException {
        try {
            if (connection != null) {
                System.out.println("Cannot create new connection, one exists already");
            } else {
                connection = DriverManager.getConnection(url, username, password);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }
        return connection;
    }
}
