package transferobjects;

/**
 * Title DTO
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class TitleDTO {

    private String ISBN;
    private String titleName;
    private Integer editionNumber;
    private Integer copyright;

    /**
     * get ISBN
     *
     * @return ISBN
     */
    public String getISBN() {
        return ISBN;
    }

    /**
     * set ISBN
     *
     * @param ISBN
     */
    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    /**
     * get name
     *
     * @return name
     */
    public String getTitleName() {
        return titleName;
    }

    /**
     * set name
     *
     * @param titleName
     */
    public void setTitleName(String titleName) {
        this.titleName = titleName;
    }

    /**
     * get edition number
     *
     * @return editionNumber
     */
    public Integer getEditionNumber() {
        return editionNumber;
    }

    /**
     * set edition number
     *
     * @param editionNumber
     */
    public void setEditionNumber(Integer editionNumber) {
        this.editionNumber = editionNumber;
    }

    /**
     * get copyright
     *
     * @return copyright
     */
    public Integer getCopyright() {
        return copyright;
    }

    /**
     * set copyright
     *
     * @param copyright
     */
    public void setCopyright(Integer copyright) {
        this.copyright = copyright;
    }

}
