/**
 * File name: LibraryController.java
 * Author: Rodrigo Orozco, 041106665
 * Course: CST8288
 * Assignment: Assignment2
 * Date: 2025-07-26
 * Professor: Marwan Farah
 * Purpose:  establishes a connection to title and author tables within book
 * database via Singleton DAO framework, implementing crud behaviour via java
 * servlets
 */
package viewlayer;

import businesslayer.AuthorsBusinessLogic;
import businesslayer.TitlesBusinessLogic;
import transferobjects.AuthorDTO;
import transferobjects.TitleDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Front Controller for servlets
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class LibraryController extends HttpServlet {

    private AuthorsBusinessLogic authorsLogic;
    private TitlesBusinessLogic titlesLogic;

    /**
     * intialize
     */
    @Override
    public void init() {
        authorsLogic = new AuthorsBusinessLogic();
        titlesLogic = new TitlesBusinessLogic();
    }

    /**
     * get behaviour
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getPathInfo();
        if (action == null || action.equals("/")) {
            // Show dashboard when accessing /controller
            req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
            return;
        }

        try {
            switch (action) {
                // Author routes
                case "/authors":
                    listAuthors(req, resp);
                    break;
                case "/authors/add":
                    req.getRequestDispatcher("/views/AddAuthor.jsp").forward(req, resp);
                    break;
                case "/authors/edit":
                    showEditAuthorForm(req, resp);
                    break;
                case "/authors/delete":
                    showDeleteAuthorConfirm(req, resp);
                    break;

                // Title routes
                case "/titles":
                    listTitles(req, resp);
                    break;
                case "/titles/add":
                    req.getRequestDispatcher("/views/AddTitle.jsp").forward(req, resp);
                    break;
                case "/titles/edit":
                    showEditTitleForm(req, resp);
                    break;
                case "/titles/delete":
                    showDeleteTitleForm(req, resp);
                    break;

                default:
                    listAuthors(req, resp);
                    break;
            }
        } catch (SQLException ex) {
            log(ex.getMessage(), ex);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }

    /**
     * post behaviour
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getPathInfo();

        try {
            switch (action) {
                // Author actions
                case "/authors/add":
                    addAuthor(req);
                    break;
                case "/authors/edit":
                    updateAuthor(req);
                    break;
                case "/authors/delete":
                    deleteAuthor(req);
                    break;

                // Title actions
                case "/titles/add":
                    addTitle(req);
                    break;
                case "/titles/edit":
                    updateTitle(req);
                    break;
                case "/titles/delete":
                    deleteTitle(req);
                    break;

                default:
                    listAuthors(req, resp);
            }

            // Always redirect to list view after POST
            if (action.startsWith("/authors")) {
                resp.sendRedirect(req.getContextPath() + "/controller/authors");
            } else {
                resp.sendRedirect(req.getContextPath() + "/controller/titles");
            }

        } catch (SQLException ex) {
            log(ex.getMessage(), ex);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }

    // ========== Author Methods ==========
    /**
     * list authors
     *
     * @param req
     * @param resp
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void listAuthors(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        List<AuthorDTO> authors = authorsLogic.getAllAuthors();
        req.setAttribute("authors", authors);
        req.getRequestDispatcher("/views/GetAuthors.jsp").forward(req, resp);
    }

    /**
     * add author
     *
     * @param req
     * @throws SQLException
     */
    private void addAuthor(HttpServletRequest req) throws SQLException {
        String firstName = req.getParameter("firstName");
        String lastName = req.getParameter("lastName");
        AuthorDTO author = new AuthorDTO();
        author.setFirstName(firstName);
        author.setLastName(lastName);
        authorsLogic.addAuthor(author);
    }

    /**
     * edit author form
     *
     * @param req
     * @param resp
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void showEditAuthorForm(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        AuthorDTO author = authorsLogic.getAuthorById(id);
        req.setAttribute("author", author);
        req.getRequestDispatcher("/views/EditAuthor.jsp").forward(req, resp);
    }

    /**
     * update author
     *
     * @param req
     * @throws SQLException
     */
    private void updateAuthor(HttpServletRequest req) throws SQLException {
        AuthorDTO author = new AuthorDTO();
        author.setAuthorID(Integer.parseInt(req.getParameter("id")));
        author.setFirstName(req.getParameter("firstName"));
        author.setLastName(req.getParameter("lastName"));
        authorsLogic.updateAuthor(author);
    }

    /**
     * delete author form
     *
     * @param req
     * @param resp
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void showDeleteAuthorConfirm(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        AuthorDTO author = authorsLogic.getAuthorById(id);
        req.setAttribute("author", author);
        req.getRequestDispatcher("/views/DeleteAuthor.jsp").forward(req, resp);
    }

    /**
     * delete author
     *
     * @param req
     * @throws SQLException
     */
    private void deleteAuthor(HttpServletRequest req) throws SQLException {
        int id = Integer.parseInt(req.getParameter("id"));
        authorsLogic.deleteAuthor(id);
    }

    // ========== Title Methods ==========
    /**
     * list titles
     *
     * @param req
     * @param resp
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void listTitles(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        List<TitleDTO> titles = titlesLogic.getAllTitles();
        req.setAttribute("titles", titles);
        req.getRequestDispatcher("/views/GetTitles.jsp").forward(req, resp);
    }

    /**
     * add title
     *
     * @param req
     * @throws SQLException
     */
    private void addTitle(HttpServletRequest req) throws SQLException {
        TitleDTO title = new TitleDTO();
        title.setISBN(req.getParameter("ISBN"));
        title.setTitleName(req.getParameter("title"));
        title.setEditionNumber(Integer.parseInt(req.getParameter("editionNumber")));
        title.setCopyright(Integer.parseInt(req.getParameter("copyright")));
        titlesLogic.addTitle(title);
    }

    /**
     * edit title form
     *
     * @param req
     * @param resp
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void showEditTitleForm(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        String ISBN = req.getParameter("ISBN");
        TitleDTO title = titlesLogic.getTitleByISBN(ISBN);
        req.setAttribute("title", title);
        req.getRequestDispatcher("/views/EditTitle.jsp").forward(req, resp);
    }

    /**
     * edit title
     *
     * @param req
     * @throws SQLException
     */
    private void updateTitle(HttpServletRequest req) throws SQLException {
        TitleDTO title = new TitleDTO();
        title.setISBN(req.getParameter("ISBN"));
        title.setTitleName(req.getParameter("title"));
        title.setEditionNumber(Integer.parseInt(req.getParameter("editionNumber")));
        title.setCopyright(Integer.parseInt(req.getParameter("copyright")));
        titlesLogic.updateTitle(title);
    }

    /**
     * delete title form
     *
     * @param req
     * @param resp
     * @throws SQLException
     * @throws ServletException
     * @throws IOException
     */
    private void showDeleteTitleForm(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        String ISBN = req.getParameter("ISBN");
        TitleDTO title = titlesLogic.getTitleByISBN(ISBN);
        req.setAttribute("title", title);
        req.getRequestDispatcher("/views/DeleteTitle.jsp").forward(req, resp);
    }

    /**
     * delete title
     *
     * @param req
     * @throws SQLException
     */
    private void deleteTitle(HttpServletRequest req) throws SQLException {
        String ISBN = req.getParameter("ISBN");
        titlesLogic.deleteTitle(ISBN);
    }

    /**
     * base info
     *
     * @return string
     */
    @Override
    public String getServletInfo() {
        return "LibraryController Servlet: Handles both Authors and Titles";
    }
}
