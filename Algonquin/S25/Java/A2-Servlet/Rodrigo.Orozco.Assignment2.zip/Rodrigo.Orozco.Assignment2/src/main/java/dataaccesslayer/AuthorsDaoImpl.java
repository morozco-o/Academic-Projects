package dataaccesslayer;

import java.util.List;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import transferobjects.AuthorDTO;

/**
 * Authors DAO
 *
 * References: Ram N. (2013). Data Access Object Design Pattern or DAO Pattern
 * [blog] Retrieved from
 * http://ramj2ee.blogspot.in/2013/08/data-access-object-design-pattern-or.html
 *
 * @author Stanley Pieda
 */
public class AuthorsDaoImpl {

    public AuthorsDaoImpl() {
    }

    /**
     * get authors
     *
     * @return list of authors
     * @throws SQLException
     */
    public List<AuthorDTO> getAllAuthors() throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<AuthorDTO> authors = null;
        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement(
                    "SELECT authorID, firstName, lastName FROM authors ORDER BY authorID");
            rs = pstmt.executeQuery();
            authors = new ArrayList<AuthorDTO>();
            while (rs.next()) {
                AuthorDTO author = new AuthorDTO();
                author.setAuthorID(new Integer(rs.getInt("authorID")));
                author.setFirstName(rs.getString("firstName"));
                author.setLastName(rs.getString("lastName"));
                authors.add(author);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return authors;
    }

    /**
     * add author
     *
     * @param author
     */
    public void addAuthor(AuthorDTO author) {
        Connection con = null;
        PreparedStatement pstmt = null;
        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement("INSERT INTO authors (firstName, lastName) VALUES(?, ?)");
            pstmt.setString(1, author.getFirstName());
            pstmt.setString(2, author.getLastName());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    /**
     * get specified author
     *
     * @param authorID
     * @return author
     */
    public AuthorDTO getAuthorByAuthorId(Integer authorID) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        AuthorDTO author = null;

        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement(
                    "SELECT * FROM Authors WHERE AuthorID = ?");
            pstmt.setInt(1, authorID.intValue());
            rs = pstmt.executeQuery();
            while (rs.next()) {
                author = new AuthorDTO();
                author.setAuthorID(rs.getInt("AuthorID"));
                author.setFirstName(rs.getString("FirstName"));
                author.setLastName(rs.getString("LastName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (pstmt != null) {
                    pstmt.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return author;
    }

    /**
     * update author
     *
     * @param author
     */
    public void updateAuthor(AuthorDTO author) {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement(
                    "UPDATE Authors SET FirstName = ?, "
                    + "LastName = ? WHERE AuthorID = ?");
            pstmt.setString(1, author.getFirstName());
            pstmt.setString(2, author.getLastName());
            pstmt.setInt(3, author.getAuthorID());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    /**
     * delete specific author
     *
     * @param authorId
     */
    public void deleteAuthor(Integer authorId) {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement(
                    "DELETE FROM Authors WHERE AuthorID = ?");
            pstmt.setInt(1, authorId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

}
