package viewlayer;

import businesslayer.LoginConfig;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Controller for login page
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class LoginController extends HttpServlet {

    /**
     * get behaviour
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        showLoginForm(resp, null);
    }

    /**
     * post behaviour
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (LoginConfig.isValidLogin(username, password)) {
            // Store user in session
            request.getSession().setAttribute("user", username);

            // Redirect to dashboard
            response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
        } else {
            showLoginForm(response, "Invalid credentials");
        }
    }

    /**
     * login form
     *
     * @param resp
     * @param errorMessage
     * @throws IOException
     */
    private void showLoginForm(HttpServletResponse resp, String errorMessage)
            throws IOException {
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Library System Login</title>");
        out.println("<link rel=\"stylesheet\" href=\"" + resp.encodeURL("assets/styles.css") + "\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class=\"container\">");
        out.println("<h2>Library Management System</h2>");

        if (errorMessage != null) {
            out.println("<div style=\"color: #dc2626; margin-bottom: 1rem;\">" + errorMessage + "</div>");
        }

        out.println("<form method='post' action='login'>");
        out.println("<div style=\"margin-bottom: 1rem;\">");
        out.println("<label for=\"username\">Username:</label>");
        out.println("<input type=\"text\" id=\"username\" name=\"username\" required>");
        out.println("</div>");

        out.println("<div style=\"margin-bottom: 1.5rem;\">");
        out.println("<label for=\"password\">Password:</label>");
        out.println("<input type=\"password\" id=\"password\" name=\"password\" required>");
        out.println("</div>");

        out.println("<input type=\"submit\" value=\"Login\" class=\"btn btn-primary\" style=\"width: 100%;\">");
        out.println("</form>");

        out.println("<div class=\"footer\" style=\"margin-top: 1.5rem; text-align: center; color: #6b7280;\">");
        out.println("CST8288 - Assignment 2");
        out.println("</div>");

        out.println("</div>"); // container
        out.println("</body>");
        out.println("</html>");
    }
}
