package businesslayer;

/**
 * Simple login validator with hardcoded credentials.
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class LoginConfig {

    private static final String VALID_USERNAME = "cst8288";
    private static final String VALID_PASSWORD = "cst8288";

    public static boolean isValidLogin(String username, String password) {
        if (username == null || password == null) {
            return false;
        }
        return VALID_USERNAME.equals(username) && VALID_PASSWORD.equals(password);
    }
}
