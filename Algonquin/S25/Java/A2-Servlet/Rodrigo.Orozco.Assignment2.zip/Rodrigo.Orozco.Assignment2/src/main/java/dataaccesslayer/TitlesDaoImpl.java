package dataaccesslayer;

import java.util.List;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import transferobjects.TitleDTO;

/**
 * Title DAO
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class TitlesDaoImpl {

    public TitlesDaoImpl() {
    }

    /**
     * get all titles
     *
     * @return list of titles
     * @throws SQLException
     */
    public List<TitleDTO> getAllTitles() throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<TitleDTO> titles = null;
        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement(
                    "SELECT ISBN, title, EditionNumber, copyright FROM titles ORDER BY ISBN");
            rs = pstmt.executeQuery();
            titles = new ArrayList<TitleDTO>();
            while (rs.next()) {
                TitleDTO title = new TitleDTO();
                title.setISBN(rs.getString("ISBN"));
                title.setTitleName(rs.getString("title"));
                title.setEditionNumber(rs.getInt("EditionNumber"));
                title.setCopyright(rs.getInt("copyright"));
                titles.add(title);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return titles;
    }

    /**
     * add title
     *
     * @param title
     */
    public void addTitle(TitleDTO title) {
        Connection con = null;
        PreparedStatement pstmt = null;
        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement("INSERT INTO titles (ISBN, title, EditionNumber, copyright) VALUES(?, ?, ?, ?)");
            pstmt.setString(1, title.getISBN());
            pstmt.setString(2, title.getTitleName());
            pstmt.setInt(3, title.getEditionNumber());
            pstmt.setInt(4, title.getCopyright());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    /**
     * get specific title
     *
     * @param ISBN
     * @return title
     */
    public TitleDTO getTitleByISBN(String ISBN) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        TitleDTO title = null;

        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement(
                    "SELECT * FROM Titles WHERE ISBN = ?");
            pstmt.setString(1, ISBN);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                title = new TitleDTO();
                title.setISBN(rs.getString("ISBN"));
                title.setTitleName(rs.getString("title"));
                title.setEditionNumber(rs.getInt("EditionNumber"));
                title.setCopyright(rs.getInt("copyright"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (pstmt != null) {
                    pstmt.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return title;
    }

    /**
     * update title
     *
     * @param title
     */
    public void updateTitle(TitleDTO title) {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement("UPDATE Titles set ISBN = ?, title = ?,"
                    + " EditionNumber = ? , copyright = ?");
            pstmt.setString(1, title.getISBN());
            pstmt.setString(2, title.getTitleName());
            pstmt.setInt(3, title.getEditionNumber());
            pstmt.setInt(4, title.getCopyright());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    /**
     * delete title
     *
     * @param ISBN
     */
    public void deleteTitle(String ISBN) {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            DataSource ds = new DataSource();
            con = ds.createConnection();
            pstmt = con.prepareStatement(
                    "DELETE FROM Titles WHERE ISBN = ?");
            pstmt.setString(1, ISBN);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }

                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

}
