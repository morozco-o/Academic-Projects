package businesslayer;

import dataaccesslayer.AuthorsDaoImpl;
import java.util.List;
import java.sql.SQLException;
import transferobjects.AuthorDTO;

/**
 * Business layer logic author
 *
 * @author Stanley Pieda
 */
public class AuthorsBusinessLogic {

    private AuthorsDaoImpl authorsDao = null;

    public AuthorsBusinessLogic() {
        authorsDao = new AuthorsDaoImpl();
    }

    /**
     * get authors
     *
     * @return list of authors
     * @throws SQLException
     */
    public List<AuthorDTO> getAllAuthors() throws SQLException {
        return authorsDao.getAllAuthors();
    }

    /**
     * get specified author
     *
     * @param authorID
     * @return author
     */
    public AuthorDTO getAuthorById(Integer authorID) {
        return authorsDao.getAuthorByAuthorId(authorID);
    }

    /**
     * add author
     *
     * @param author
     */
    public void addAuthor(AuthorDTO author) {
        authorsDao.addAuthor(author);
    }

    /**
     * update author
     *
     * @param author
     */
    public void updateAuthor(AuthorDTO author) {
        authorsDao.updateAuthor(author);
    }

    /**
     * delete specific author
     *
     * @param authorId
     */
    public void deleteAuthor(Integer authorId) {
        authorsDao.deleteAuthor(authorId);
    }
}
