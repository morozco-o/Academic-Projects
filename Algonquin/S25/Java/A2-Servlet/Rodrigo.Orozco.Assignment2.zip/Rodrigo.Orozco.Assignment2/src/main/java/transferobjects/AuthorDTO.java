/* File: AuthorDTO.java
 * AuthorDTO: Stanley Pieda
 * Date: 2015
 * Modified: May/2022 changed AuthorDTO to AuthorDTO - kriger
 * Description: Demonstration of DAO Design Pattern
 */
package transferobjects;

/**
 * Authors DTO
 *
 * @author Stanley Pieda
 */
public class AuthorDTO {

    private Integer authorID;
    private String firstName;
    private String lastName;

    /**
     * get id
     *
     * @return authorID
     */
    public Integer getAuthorID() {
        return authorID;
    }

    /**
     * set id
     *
     * @param authorID
     */
    public void setAuthorID(Integer authorID) {
        this.authorID = authorID;
    }

    /**
     * get first name
     *
     * @return firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * set first name
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * get last name
     *
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * set last name
     *
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

}
