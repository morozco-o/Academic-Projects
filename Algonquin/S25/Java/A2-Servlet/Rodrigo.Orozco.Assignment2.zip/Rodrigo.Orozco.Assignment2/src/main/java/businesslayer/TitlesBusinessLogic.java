package businesslayer;

import dataaccesslayer.TitlesDaoImpl;
import java.util.List;
import java.sql.SQLException;
import transferobjects.TitleDTO;

/**
 * Business layer logic titles
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class TitlesBusinessLogic {

    private TitlesDaoImpl titlesDao = null;

    public TitlesBusinessLogic() {
        titlesDao = new TitlesDaoImpl();
    }

    /**
     * get all titles
     *
     * @return list of titles
     * @throws SQLException
     */
    public List<TitleDTO> getAllTitles() throws SQLException {
        return titlesDao.getAllTitles();
    }

    /**
     * get specific title
     *
     * @param ISBN
     * @return title
     */
    public TitleDTO getTitleByISBN(String ISBN) {
        return titlesDao.getTitleByISBN(ISBN);
    }

    /**
     * add title
     *
     * @param title
     */
    public void addTitle(TitleDTO title) {
        titlesDao.addTitle(title);
    }

    /**
     * update title
     *
     * @param title
     */
    public void updateTitle(TitleDTO title) {
        titlesDao.updateTitle(title);
    }

    /**
     * delete title
     *
     * @param ISBN
     */
    public void deleteTitle(String ISBN) {
        titlesDao.deleteTitle(ISBN);
    }
}
