package convertPkg;

/**
 * Kelvin to Rankine strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class KelvinToRankineStrategy implements IConvert {

    /**
     * convert Kelvin to Rankine
     *
     * @param value
     * @return rankine value
     */
    @Override
    public Double convert(Double value) {
        return (value * 1.8);
    }
}
