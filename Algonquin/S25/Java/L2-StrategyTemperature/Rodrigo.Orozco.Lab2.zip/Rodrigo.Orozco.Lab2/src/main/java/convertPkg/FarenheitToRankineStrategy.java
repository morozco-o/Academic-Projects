package convertPkg;

/**
 * Farenheit to Rankine strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class FarenheitToRankineStrategy implements IConvert {

    /**
     * convert Farenheit to Rankine
     *
     * @param value
     * @return rankine value
     */
    @Override
    public Double convert(Double value) {
        return (value + 459.67);
    }
}
