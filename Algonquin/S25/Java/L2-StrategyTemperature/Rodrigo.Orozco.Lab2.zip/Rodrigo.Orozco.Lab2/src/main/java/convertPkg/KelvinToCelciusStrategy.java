package convertPkg;

/**
 * Kelvin to Celcius strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class KelvinToCelciusStrategy implements IConvert {

    /**
     * convert Kelvin to Celcius
     *
     * @param value
     * @return celcius value
     */
    @Override
    public Double convert(Double value) {
        return (value - 273.15);
    }
}
