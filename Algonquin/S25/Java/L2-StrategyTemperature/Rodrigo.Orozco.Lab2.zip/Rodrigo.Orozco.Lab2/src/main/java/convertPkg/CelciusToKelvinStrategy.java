package convertPkg;

/**
 * Celcius to Kelvin strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class CelciusToKelvinStrategy implements IConvert {

    /**
     * convert ceclius to kelvin
     *
     * @param value
     * @return kelvin value
     */
    @Override
    public Double convert(Double value) {
        return (value + 273.15);
    }
}
