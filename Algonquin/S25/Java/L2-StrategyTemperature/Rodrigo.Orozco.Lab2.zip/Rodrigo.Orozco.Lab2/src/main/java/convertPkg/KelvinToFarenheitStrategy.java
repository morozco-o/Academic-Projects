package convertPkg;

/**
 * Kelvin to Farenheit strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class KelvinToFarenheitStrategy implements IConvert {

    /**
     * convert Kelvin to Farenheit
     *
     * @param value
     * @return Farenheit value
     */
    @Override
    public Double convert(Double value) {
        return (((value - 273.15) * (9.0 / 5.0)) + 32);
    }
}
