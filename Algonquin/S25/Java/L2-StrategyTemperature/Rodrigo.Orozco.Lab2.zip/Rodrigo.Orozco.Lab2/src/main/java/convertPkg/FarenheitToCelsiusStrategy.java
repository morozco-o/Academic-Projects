package convertPkg;

/**
 * Farenheit to Celcius strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class FarenheitToCelsiusStrategy implements IConvert {

    /**
     * convert Farenheit to celcius
     *
     * @param value
     * @return celcius value
     */
    @Override
    public Double convert(Double value) {
        return ((value - 32) * (5.0 / 9.0));
    }
}
