package convertPkg;

/**
 * Rankine to Celcius strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class RankineToCelciusStrategy implements IConvert {

    /**
     * convert Rankine to Celcius
     *
     * @param value
     * @return Celcius value
     */
    @Override
    public Double convert(Double value) {
        return ((value - 491.67) * (5.0 / 9.0));
    }
}
