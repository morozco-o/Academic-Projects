
package convertPkg;

/**
 * @author stico
 */
public interface IConvert {
    Double convert(Double value); 
}
