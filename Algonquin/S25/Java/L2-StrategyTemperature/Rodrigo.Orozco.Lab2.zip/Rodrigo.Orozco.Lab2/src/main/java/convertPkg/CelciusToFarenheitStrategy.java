package convertPkg;

/**
 * Celcius to Farenheit strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class CelciusToFarenheitStrategy implements IConvert {

    /**
     * convert ceclius to farenheit
     *
     * @param value
     * @return farenheit value
     */
    @Override
    public Double convert(Double value) {
        return ((value * (9.0 / 5.0)) + 32);
    }
}
