package convertPkg;

/**
 * Context Class
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class ConvertContext {

    // interface instance
    private IConvert convertor;

    //contructor
    public ConvertContext() {
    }

    /**
     * Set strategy
     * @param strategy 
     */
    public void setStrategy(IConvert strategy) {
        convertor = strategy;
    }

    /**
     * converts value
     * @param value
     * @return converted value
     */
    public Double convert(double value) {
        return convertor.convert(value);
    }

}
