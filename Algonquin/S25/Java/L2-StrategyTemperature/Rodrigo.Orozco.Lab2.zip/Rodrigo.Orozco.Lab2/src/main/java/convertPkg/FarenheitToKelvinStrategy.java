package convertPkg;

/**
 * Farenheit to Kelvin strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class FarenheitToKelvinStrategy implements IConvert {

    /**
     * convert Farenheit to Kelvin
     *
     * @param value
     * @return kelvin value
     */
    @Override
    public Double convert(Double value) {
        return (((value - 32) * (5.0 / 9.0)) + 273.15);
    }
}
