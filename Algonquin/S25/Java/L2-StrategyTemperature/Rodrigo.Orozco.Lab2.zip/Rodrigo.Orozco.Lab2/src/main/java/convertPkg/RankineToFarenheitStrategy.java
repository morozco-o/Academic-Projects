package convertPkg;

/**
 * Rankine to Farenheit strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class RankineToFarenheitStrategy implements IConvert {

    /**
     * convert Rankine to Farenheit
     *
     * @param value
     * @return farenheit value
     */
    @Override
    public Double convert(Double value) {
        return (value - 459.67);
    }
}
