package convertPkg;

/**
 * Rankine to Kelvin strategy
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class RankineToKelvinStrategy implements IConvert {

    /**
     * convert Rankine to Kelvin
     *
     * @param value
     * @return kelvin value
     */
    @Override
    public Double convert(Double value) {
        return (value * (5.0 / 9.0));
    }
}
