
/**
 * File name: ConvertMain.java
 * Author: Rodrigo Orozco, 041106665
 * Course: CST8288
 * Assignment: lab2
 * Date: 2025-07-14
 * Professor: Marwan Farah
 * Purpose:  implement Strategy design pattern with temperature conversions.
 */

import convertPkg.CelciusToFarenheitStrategy;
import convertPkg.CelciusToKelvinStrategy;
import convertPkg.CelciusToRankineStrategy;
import convertPkg.FarenheitToCelsiusStrategy;
import convertPkg.FarenheitToKelvinStrategy;
import convertPkg.FarenheitToRankineStrategy;
import convertPkg.KelvinToCelciusStrategy;
import convertPkg.KelvinToFarenheitStrategy;
import convertPkg.KelvinToRankineStrategy;
import convertPkg.RankineToCelciusStrategy;
import convertPkg.RankineToFarenheitStrategy;
import convertPkg.RankineToKelvinStrategy;
import convertPkg.ConvertContext;
import convertPkg.IConvert;

/**
 * Main Driver class
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class ConvertMain {

    public static void main(String[] args) {
        ConvertContext context = new ConvertContext();

        //Declerations
        double c = 0.0;
        double f = 100.0;
        double k = 200.0;
        double r = 150;

        // Celsius -> Fahrenheit
        context.setStrategy(new CelciusToFarenheitStrategy());
        System.out.printf("From %.2f Celcius to %.2f Farenheit\n", c, context.convert(c));

        // Celsius -> Kelvin
        context.setStrategy(new CelciusToKelvinStrategy());
        System.out.printf("From %.2f Celcius to %.2f Kelvin\n", c, context.convert(c));

        // Celsius -> Rankine
        context.setStrategy(new CelciusToRankineStrategy());
        System.out.printf("From %.2f Celcius to %.2f Rankine\n", c, context.convert(c));

        // Fahrenheit -> Celsius
        context.setStrategy(new FarenheitToCelsiusStrategy());
        System.out.printf("From %.2f Farenheit to %.2f Celcius\n", f, context.convert(f));

        // Fahrenheit -> Kelvin
        context.setStrategy(new FarenheitToKelvinStrategy());
        System.out.printf("From %.2f Farenheit to %.2f Kelvin\n", f, context.convert(f));

        // Fahrenheit -> Rankine
        context.setStrategy(new FarenheitToRankineStrategy());
        System.out.printf("From %.2f Farenheit to %.2f Rankine\n", f, context.convert(f));

        // Kelvin -> Celsius
        context.setStrategy(new KelvinToCelciusStrategy());
        System.out.printf("From %.2f Kelvin to %.2f Celcius\n", k, context.convert(k));

        // Kelvin -> Fahrenheit
        context.setStrategy(new KelvinToFarenheitStrategy());
        System.out.printf("From %.2f Kelvin to %.2f Farenheit\n", k, context.convert(k));

        // Kelvin -> Fahrenheit
        context.setStrategy(new KelvinToRankineStrategy());
        System.out.printf("From %.2f Kelvin to %.2f Rankine\n", k, context.convert(k));

        // Rankine -> Celsius
        context.setStrategy(new RankineToCelciusStrategy());
        System.out.printf("From %.2f Rankine to %.2f Celcius\n", r, context.convert(r));

        // Rankine -> Fahrenheit
        context.setStrategy(new RankineToFarenheitStrategy());
        System.out.printf("From %.2f Rankine to %.2f Farenheit\n", r, context.convert(r));

        // Rankine -> Kelvin
        context.setStrategy(new RankineToKelvinStrategy());
        System.out.printf("From %.2f Rankine to %.2f Kelvin\n", r, context.convert(r));

        System.out.println("Program by: Rodrigo Orozco (041106665)");
        System.out.println("For: 25s CST8288 Section 021 Lab 2");

    }

}
