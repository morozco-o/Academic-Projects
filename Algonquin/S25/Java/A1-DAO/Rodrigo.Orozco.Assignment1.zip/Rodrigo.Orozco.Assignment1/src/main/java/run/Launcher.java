/**
 * File name: Launcher.java
 * Author: Rodrigo Orozco, 041106665
 * Course: CST8288
 * Assignment: Assignment1
 * Date: 2025-06-09
 * Professor: Marwan Farah
 * Purpose:  establishes a connection to recipients table within Ontario
 * database via Singleton DAO framework, implementing adding, updating, and
 * deleting recipient objects
 */
package run;

import businesslayer.RecipientsBusinessLogic;
import businesslayer.ValidationException;
import static dataaccesslayer.DataSource.getConnection;
import java.sql.ResultSetMetaData;
import java.sql.ResultSet;
import java.util.List;
import java.util.Scanner;
import transferobjects.RecipientsDTO;

/**
 * Main Driver class
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class Launcher {

    public static void main(String[] args) throws ValidationException {
        //Declerations
        RecipientsBusinessLogic logic = new RecipientsBusinessLogic();
        List<RecipientsDTO> list = null;
        RecipientsDTO recipient = null;

        //Intial print
        System.out.println("Printing All Recipients");
        list = logic.getAllRecipients();
        logic.printRecipients();
        System.out.println();

        //Insert
        System.out.println("Inserting One New Recipient");
        recipient = new RecipientsDTO();
        recipient.setName("TestNameADD");
        recipient.setYear(9999);
        recipient.setCity("Ottawa");
        recipient.setCategory("Test Category");

        logic.addRecipient(recipient);
        list = logic.getAllRecipients();
        logic.printRecipients();
        System.out.println();

        //Delete
        System.out.println("Deleting the Last Recipient");
        recipient = list.get(list.size() - 1);
        logic.deleteRecipient(recipient);
        list = logic.getAllRecipients();
        logic.printRecipients();
        System.out.println();

        //Metadata
        System.out.println("Printing Metadata for Recipients Table");
        logic.printMeta();

        System.out.println();
        System.out.println("Program by: Rodrigo Orozco (041106665)");
        System.out.println("For: 25s CST8288 Section 021 Assignment 1");
    }

}
