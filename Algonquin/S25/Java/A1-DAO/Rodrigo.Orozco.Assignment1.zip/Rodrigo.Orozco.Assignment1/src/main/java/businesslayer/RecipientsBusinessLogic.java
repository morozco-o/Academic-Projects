package businesslayer;

import java.util.List;
import dataaccesslayer.RecipientsDao;
import dataaccesslayer.RecipientsDaoImpl;
import transferobjects.RecipientsDTO;

/**
 * Business layer logic creation
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class RecipientsBusinessLogic {

    //Declerations
    private RecipientsDao RecipientsDao = null;
    private RecipientValidation validation = null;

    /**
     * Creates implementation of other business layer
     */
    public RecipientsBusinessLogic() {
        RecipientsDao = new RecipientsDaoImpl();
        validation = new RecipientValidation();
    }

    /**
     * get specific Recipient
     *
     * @param AwardID
     * @return recipientByAwardID
     */
    public RecipientsDTO getRecipient(Integer AwardID) {
        return RecipientsDao.getRecipientByAwardId(AwardID);
    }

    /**
     * get all recipients
     *
     * @return Recipients list
     */
    public List<RecipientsDTO> getAllRecipients() {
        return RecipientsDao.getAllRecipients();
    }

    /**
     * Add a recipient
     *
     * @param recipient
     * @throws ValidationException
     */
    public void addRecipient(RecipientsDTO recipient) throws ValidationException {
        validation.cleanRecipients(recipient);
        validation.validateRecipient(recipient);
        RecipientsDao.addRecipient(recipient);
    }

    /**
     * Update a recipient
     *
     * @param recipient
     * @throws ValidationException
     */
    public void updateRecipient(RecipientsDTO recipient) throws ValidationException {
        validation.cleanRecipients(recipient);
        validation.validateRecipient(recipient);
        RecipientsDao.updateRecipient(recipient);
    }

    /**
     * delete a recipient
     *
     * @param recipient
     */
    public void deleteRecipient(RecipientsDTO recipient) {
        RecipientsDao.deleteRecipient(recipient);
    }

    /**
     * Prints Recipient list
     */
    public void printRecipients() {
        RecipientsDao.printRecipients();
    }

    /**
     * Print meta data
     */
    public void printMeta() {
        RecipientsDao.printMeta();
    }
}
