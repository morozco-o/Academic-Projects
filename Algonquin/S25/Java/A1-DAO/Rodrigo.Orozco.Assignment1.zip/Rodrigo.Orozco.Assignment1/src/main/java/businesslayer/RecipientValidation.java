package businesslayer;

import transferobjects.RecipientsDTO;

/**
 * Check validity of additions to table
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class RecipientValidation {

    private static final int NAME_MAX_LENGTH = 40;
    private static final int CITY_MAX_LENGTH = 30;
    private static final int CATEGORY_MAX_LENGTH = 40;

    /**
     * Cleans data entry for recipient
     *
     * @param recipient
     */
    protected void cleanRecipients(RecipientsDTO recipient) {
        if (recipient.getName() != null) {
            recipient.setName(recipient.getName().trim());
        }
        if (recipient.getCity() != null) {
            recipient.setCity(recipient.getCity().trim());
        }
        if (recipient.getCategory() != null) {
            recipient.setCategory(recipient.getCategory().trim());
        }
    }

    /**
     * Pass Recipient info to validateString
     *
     * @param recipient
     * @throws ValidationException
     */
    protected void validateRecipient(RecipientsDTO recipient) throws ValidationException {
        validateString(recipient.getName(), "Name", NAME_MAX_LENGTH, false);
        validateString(recipient.getCity(), "City", CITY_MAX_LENGTH, false);
        validateString(recipient.getCategory(), "Category", CATEGORY_MAX_LENGTH, false);
    }

    /**
     * Checks proper entries for recipient
     *
     * @param value
     * @param fieldName
     * @param maxLength
     * @param isNullAllowed
     * @throws ValidationException
     */
    private void validateString(String value, String fieldName, int maxLength, boolean isNullAllowed)
            throws ValidationException {
        if (value == null && isNullAllowed) {
            //return; // null permitted, nothing to validate
        } else if (value == null && !isNullAllowed) {
            throw new ValidationException(String.format("%s cannot be null",
                    fieldName));
        } else if (value.length() == 0) {
            throw new ValidationException(String.format("%s cannot be empty or only whitespace",
                    fieldName));
        } else if (value.length() > maxLength) {
            throw new ValidationException(String.format("%s cannot exceed %d characters",
                    fieldName, maxLength));
        }
    }
}
