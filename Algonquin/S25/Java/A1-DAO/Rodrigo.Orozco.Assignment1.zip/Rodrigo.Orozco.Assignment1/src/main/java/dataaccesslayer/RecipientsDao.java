package dataaccesslayer;

import java.util.List;
import transferobjects.RecipientsDTO;

/**
 * DAO interface
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public interface RecipientsDao {

    /**
     * List of Recipients
     *
     * @return
     */
    List<RecipientsDTO> getAllRecipients();

    /**
     * return specific recipient
     *
     * @param AwardID
     * @return recipient
     */
    RecipientsDTO getRecipientByAwardId(Integer AwardID);

    /**
     * add recipient
     *
     * @param recipient
     */
    void addRecipient(RecipientsDTO recipient);

    /**
     * Update recipient
     *
     * @param recipient
     */
    void updateRecipient(RecipientsDTO recipient);

    /**
     * Delete recipient
     *
     * @param recipient
     */
    void deleteRecipient(RecipientsDTO recipient);

    /**
     * Print list of recipients
     */
    void printRecipients();

    /**
     * Print meta table data
     */
    void printMeta();
}
