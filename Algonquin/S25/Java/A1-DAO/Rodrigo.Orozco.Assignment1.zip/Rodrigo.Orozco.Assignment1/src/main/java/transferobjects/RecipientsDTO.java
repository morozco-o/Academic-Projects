package transferobjects;

/**
 * Transferrable Object class of Recipients Table
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class RecipientsDTO {

    private Integer AwardID;
    private String Name;
    private Integer Year;
    private String City;
    private String Category;

    /**
     * Get AwardID
     *
     * @return AwardID
     */
    public Integer getAwardID() {
        return AwardID;
    }

    /**
     * Get Name
     *
     * @return Name
     */
    public String getName() {
        return Name;
    }

    /**
     * Get Year
     *
     * @return Year
     */
    public Integer getYear() {
        return Year;
    }

    /**
     * Get City
     *
     * @return City
     */
    public String getCity() {
        return City;
    }

    /**
     * Get Category
     *
     * @return Category
     */
    public String getCategory() {
        return Category;
    }

    /**
     * Set AwardID
     *
     * @param AwardID
     */
    public void setAwardID(Integer AwardID) {
        this.AwardID = AwardID;
    }

    /**
     * Set Name
     *
     * @param Name
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * Set Year
     *
     * @param Year
     */
    public void setYear(Integer Year) {
        this.Year = Year;
    }

    /**
     * Set City
     *
     * @param City
     */
    public void setCity(String City) {
        this.City = City;
    }

    /**
     * Set Category
     *
     * @param Category
     */
    public void setCategory(String Category) {
        this.Category = Category;
    }

}
