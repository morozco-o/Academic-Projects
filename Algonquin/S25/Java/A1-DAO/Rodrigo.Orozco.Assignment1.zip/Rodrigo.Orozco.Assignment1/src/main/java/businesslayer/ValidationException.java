package businesslayer;

/**
 * Creation of exception
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class ValidationException extends Exception {

    //Different Constructors
    public ValidationException() {
        super("Data not in valid format");
    }

    public ValidationException(String message) {
        super(message);
    }

    public ValidationException(String message, Throwable throwable) {
        super(message, throwable);
    }

    public ValidationException(Throwable throwable) {
        super(throwable);
    }
}
