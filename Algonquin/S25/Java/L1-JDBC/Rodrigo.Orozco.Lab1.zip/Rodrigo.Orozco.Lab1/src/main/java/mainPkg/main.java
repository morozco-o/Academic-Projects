/**
 * File name: main.java
 * Author: Rodrigo Orozco, 041106665
 * Course: CST8288
 * Assignment: lab1
 * Date: 2025-06-02
 * Professor: Marwan Farah
 * Purpose:  establishes a connection to recipients table within Ontario 
 * database, pulling entries matching a random year generated
 */

package mainPkg;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Properties;
import java.security.SecureRandom;
import java.sql.PreparedStatement;

/**
 * Main Driver class
 *
 * @author Rodrigo Orozco
 * @version 1
 * @since 17
 */
public class main {

    public static void main(String args[]) {
        // Declearations
        Properties props = new Properties();
        Statement statement = null;
        PreparedStatement prepStatement = null;
        ResultSet resultSet = null;
        SecureRandom rand = new SecureRandom();
        int randInt = rand.nextInt(1987, 2021);

        // try-with-resources inputing properties files
        try (InputStream in = Files.newInputStream(Paths.get("src/main/java/database.properties"));) {
            props.load(in);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }// catch()

        String url = props.getProperty("jdbc.url");
        String username = props.getProperty("jdbc.username");
        String password = props.getProperty("jdbc.password");

        // try establish connection to database           
        try (Connection connection = DriverManager.getConnection(url, username, password);) {
            
            String query = "SELECT * FROM Recipients where Year = ?";
            prepStatement = connection.prepareStatement(query);// create Statement for querying database
            prepStatement.setInt(1, randInt);

            resultSet = prepStatement.executeQuery();
            // process query results
            ResultSetMetaData metaData = resultSet.getMetaData();
            int numberOfColumns = metaData.getColumnCount();
            System.out.println("Recipients Table - Column Attributes");

            // loop through columns and get their data types
            for (int i = 1; i <= numberOfColumns; i++) {
                System.out.printf("%-8s\t", metaData.getColumnName(i));
                System.out.printf("%-8s\t", metaData.getColumnTypeName(i));
                System.out.printf("%-8s\t", metaData.getColumnClassName(i));
                System.out.printf("\n");
            }

            System.out.println();

            if (!resultSet.isBeforeFirst()) {
                System.out.println("No Results found for year: "+randInt);
            } else {

                // loop through columns and get their names
                // columns start at 1 NOT zero !! - GJK
                for (int i = 1; i <= numberOfColumns; i++) {
                    if (i != 2) {
                        System.out.printf("%-8s\t", metaData.getColumnName(i));
                    } else {
                        System.out.printf("%-26s\t", metaData.getColumnName(i));
                    }
                }
                System.out.println();

                // loop through row and column and retrieve value of the cell
                while (resultSet.next()) {
                    for (int i = 1; i <= numberOfColumns; i++) {
                        if (i != 2) {
                            System.out.printf("%-8s\t", resultSet.getObject(i));
                        } else {
                            //spacing for name column
                            System.out.printf("%-26s\t", resultSet.getObject(i));
                        }
                    }
                    System.out.println();
                }
            }
            System.out.println();
            System.out.println("Program by: Rodrigo Orozco (041106665)");
            System.out.println("For: 25s CST8288 Section 021 Lab 1");
        } // end try
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } // end catch                                                     

    } // end main
}

